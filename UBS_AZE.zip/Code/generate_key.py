# 1
# from cryptography.fernet import Fernet
#
# key = Fernet.generate_key()
#
# with open("D:/Upload Bank Statement/creds.key", "wb") as f:
#     f.write(key)
#
# print("✅ Key generated: creds.key")
# print("🚫 DO NOT SHARE OR COMMIT THIS FILE")




2
from cryptography.fernet import Fernet

with open("D:/Upload Bank Statement/Code/creds.key", "rb") as f:
    key = f.read()

fernet = Fernet(key)

with open("D:/Upload Bank Statement/creds.txt", "rb") as f:
    data = f.read()

encrypted = fernet.encrypt(data)

with open("D:/Upload Bank Statement/Code/creds.enc", "wb") as f:
    f.write(encrypted)

print("✅ creds.txt encrypted → creds.enc")
